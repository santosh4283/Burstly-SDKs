//
//  DownloadTracker.h
//  libDownloadTracker
//
//  Created by Nikolay Remizevich on 12.01.10.
//  Copyright 2010 App Media Group, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface DownloadTracker : NSObject {

}

+ (void)track;

@end
