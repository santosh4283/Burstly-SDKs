//
//  BurstlyCurrency.h
//  Burstly
//
//  Created by Nick Remizevich on 8/15/11.
//  Copyright (c) 2011 Burstly Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol BurstlyCurrencyDelegate <NSObject>

@optional

- (void)didGetBalance: (NSNumber *)balance;
- (void)didFailToGetBalance;

- (void)didUpdateBalance: (NSNumber *)newBalance;
- (void)didFailToUpdateBalance;

@end

@interface BurstlyCurrency : NSObject

+ (void)setDelegate: (NSObject<BurstlyCurrencyDelegate> *)delegate;

+ (void)beginGetBalance: (NSString *)publisher;
+ (void)beginUpdateBalance: (NSString *)publisher byAmount: (double)amount;

@end
